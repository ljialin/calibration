#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <random>
#include <WINDOWS.H>
#include "json.hpp"

using json = nlohmann::json;
using namespace std;

#define INF 1e7
#define DELTA 1e-6
#define PI 4.0*atan(1.0)

// Number of decision variables
#define count_dec 28

// MAX is the number of objective functions
#define count_obj 495

//MAX_CONSTRAINT is the maximum number of constraints
#define MAX_CONSTRAINT 0

//--------------------------------------------------------------------------------------------------
const int Max_popsize = 800;

////////------------ model parameters
static const int case_num = 33;

static const int outputs_per_case_num = 15;

static string output_partens[] = {" 0 0 0 0 0 "," 1 1 0 0 0 "," 1 1 1 0 0 "};

static string simulator_path = "./MyFunc.exe";

string result_path = "SDE_result.txt";

static double correct_solution[28] = {
    0.85, 3, 3.2, 0.85, 0.83, 0.89, 0.88, 0.96, 0.017, 1, 12, 0.98, 0.98, 0.999, 0.07, 0.04, 0.022, 0.012, 0, 0.99, 0.995, 0.94, 0.985, 0.99, 0.99, 1, 0.5, 0.27};

static double ref_output[case_num][outputs_per_case_num] = {
    35.2, 0.382, 910.3, 1493.4, 732.1, 230.3, 244.9, 405.2, 417, 473.3, 170.8, 230.5, 421.7, 20.22, 0.138,
    15.72, 0.092, 594.5, 510, 516.2, 90.7, 95.8, 296.1, 303.4, 160.4, 59.4, 89.7, 306.5, 3.33, 0.138,
    29.13, 0.295, 867.1, 1200, 702.9, 187.1, 198.9, 389.9, 401.2, 380.5, 137.2, 187.1, 405.7, 13.83, 0.138,
    22.81, 0.159, 703.6, 799.7, 608.8, 144.2, 152.1, 353.2, 361.7, 251.6, 94.3, 142.4, 365.4, 7.49, 0.138,
    19.78, 0.193, 826.4, 799.8, 663.9, 122.5, 130.3, 364.1, 374.9, 254.3, 90.8, 122.7, 379.2, 9.52, 0.138,
    16.95, 0.122, 693, 600.1, 587.7, 103.1, 109.1, 334.6, 343.1, 189.6, 69.8, 102.3, 346.8, 6.38, 0.138,
    13.86, 0.082, 624.1, 450.2, 542.6, 84.5, 88.8, 316.7, 324, 141.9, 54.7, 83.1, 327.1, 3.96, 0.138,
    15.05, 0.072, 586.7, 450.2, 538, 96.9, 101.1, 327.8, 334.2, 141.4, 56.1, 94.4, 336.8, 2.15, 0.138,
    16.48, 0.09, 623.9, 520.1, 561.9, 105.5, 110.5, 336.8, 343.9, 163.3, 63, 103.2, 346.9, 3.05, 0.138,
    19.01, 0.125, 686.3, 649.8, 599.2, 120.9, 127.3, 350.7, 358.9, 204.6, 77.1, 119.1, 362.4, 4.81, 0.138,
    11.83, 0.145, 949.4, 524.8, 715.8, 75, 80, 379.8, 392.4, 168.3, 59, 75.6, 397.3, 5.81, 0.138,
    11.28, 0.109, 817.7, 450.1, 644.9, 69.4, 73.8, 353, 363.4, 143.8, 51.2, 69.5, 367.7, 4.73, 0.138,
    10.74, 0.089, 746.5, 399.9, 605.1, 65.3, 69.3, 337.5, 346.7, 127.3, 46.1, 65.1, 350.6, 4.02, 0.138,
    11.72, 0.141, 968.3, 513.4, 742.8, 77.1, 82.1, 404.9, 417.2, 164.7, 58.6, 77.4, 422.1, 5.03, 0.138,
    11.18, 0.111, 863.9, 450.1, 686.2, 72.3, 76.8, 382.8, 393.5, 143.9, 52.1, 72.2, 397.9, 4.19, 0.138,
    9.91, 0.083, 788.9, 370, 641.4, 63.7, 67.5, 365, 374.4, 117.9, 43.5, 63.2, 378.4, 3.17, 0.138,
    21.62, 0.106, 635.4, 660.6, 598.2, 150.8, 156.9, 372.7, 379.5, 206.8, 82.6, 146.4, 382.3, 2.8, 0.138,
    27.88, 0.204, 771.4, 1000.5, 675.7, 190.9, 200.7, 401.3, 410.3, 314.6, 120.3, 187.7, 414.2, 6.7, 0.138,
    32.32, 0.283, 845.6, 1249.1, 718.3, 221, 233.5, 417.7, 427.9, 394, 147.7, 218.8, 432.3, 9.63, 0.138,
    22.56, 0.277, 1060, 1000.3, 854.6, 164.8, 174.9, 490.5, 503.5, 319.7, 117.7, 164.3, 508.7, 7.74, 0.138,
    20.26, 0.219, 990.9, 849.7, 815.7, 147.4, 156, 474.3, 486.2, 270.8, 101.1, 146.3, 491.1, 6.16, 0.138,
    17.78, 0.166, 919.8, 700.2, 775.3, 129.5, 136.4, 458.1, 468.8, 222.7, 84.5, 127.7, 473.4, 4.64, 0.138,
    17.71, 0.164, 808, 699.7, 655.7, 110.2, 117.1, 363.4, 373.8, 222.6, 80, 110.1, 378, 6.78, 0.138,
    16.32, 0.128, 734, 599.6, 613.7, 100.6, 106.6, 346.9, 356, 190, 69.5, 100, 359.9, 5.43, 0.138,
    14.42, 0.099, 684, 499.7, 583.3, 88.7, 93.7, 335.1, 343.4, 158, 58.7, 87.7, 346.9, 4.08, 0.138,
    18.27, 0.109, 683.1, 600.1, 613.8, 122.9, 128.7, 370.3, 378.1, 188.7, 73.2, 120.2, 381.3, 3.42, 0.138,
    21.97, 0.168, 772.5, 800.4, 665.8, 146.8, 154.7, 390.2, 399.4, 252.6, 95.2, 144.8, 403.4, 5.66, 0.138,
    27.19, 0.265, 880, 1100, 727.8, 182.4, 193.5, 414.6, 425.5, 348.6, 128.2, 181.7, 430, 9.11, 0.138,
    29.88, 0.233, 836.1, 1100.5, 735.5, 217.4, 228.1, 443.4, 453, 346.4, 134.1, 213.3, 457, 6.42, 0.138,
    33.28, 0.299, 898.6, 1300.9, 770.5, 241.5, 254.4, 457, 467.6, 410.6, 156.5, 238.1, 472.2, 8.43, 0.138,
    36.63, 0.369, 951.6, 1500.5, 800.7, 265.6, 280.7, 468.8, 480.3, 474.3, 178.6, 263, 485.1, 10.46, 0.138,
    34.66, 0.229, 820.1, 1200.4, 758.5, 273.2, 284.4, 477.9, 486.6, 376.8, 151.8, 265.5, 490.1, 4.94, 0.138,
    44.4, 0.435, 987.8, 1798.5, 850.6, 343.8, 361.5, 512.7, 524.1, 567.2, 219, 338.2, 528.9, 10.37, 0.138};

static double lower_bounds[count_dec] = {
    0.75, 2.2, 2.2, 0.75,
    0.75, 0.8, 0.8, 0.9,
    0, 0.95, 5, 0.98,
    0.98, 0.99, 0, 0,
    0, 0, 0, 0.99,
    0.99, 0.92, 0.97, 0.98,
    0.98, 0.98, 0.2, 0.2};
static double upper_bounds[count_dec] = {
    0.89, 4.5, 4.5, 0.89,
    0.89, 0.92, 0.92, 1,
    0.03, 1.05, 30, 1,
    1, 1, 0.1, 0.1,
    0.05, 0.05, 50, 1,
    1, 0.98, 0.99, 1,
    1, 1, 0.7, 0.3};
static double default_param[count_dec] = {
    0.75, 2.2, 2.2, 0.75,
    0.75, 0.8, 0.8, 0.9,
    0, 0.95, 5, 0.98,
    0.98, 0.99, 0, 0,
    0, 0, 0, 0.99,
    0.99, 0.92, 0.97, 0.98,
    0.98, 0.98, 0.2, 0.2};

// const char* input_files = "parameters.json";
// const char* tempt_files = "temp.json";
// const char* final_files="log.json";//目标文件
// const char* abstract="abstract.json";//目标文件


string input_files = "parameters.json";
string tempt_files = "temp.json";
string final_files= "log.json";
string abstract= "abstract.json";

FILE *fp;
char dummy_string[50];

////// --------------algorithm parameter
int pop_size;
int pop_size_default = 50;
int MAXFE;
int MAXFE_default = 10000;
int FE_count;
int id;
int type;
int status;
int seed;
int gen_now;
double timecost;
double Max_error;
double Max_error_default = 0.01;
double Mean_error;
double Mean_error_dafault = 0.001; // 平均匹配误差 除以num_case
int min_meanobj_idx;
int min_maxobj_idx;
double min_meanobj;
double min_maxobj;
time_t start_time;
bool stop_flag;
//--------------------stop information
int Max_gen;
int Max_gen_default = 200;
double Max_time;
double Max_time_default = 1800;
int error_mean;
int error_max;
bool stop_mean;
bool stop_max;
bool error_value;
bool stop_FE;

//--------------------------------------------------------------------------------------------------
double pro_crossover, pro_mutation;
double distri_crossover, distri_mutation;
double eeta;

double lowerbound[count_dec];
double upperbound[count_dec];


int matingpool[Max_popsize * 4 + 10];   // from zero
int pop_idx[Max_popsize * 2 + 10];

double fitness_pop[Max_popsize*2+10];
double fitness_all[Max_popsize*2+10];
double Fitness_mat[Max_popsize*2+10][Max_popsize*2+10];

bool remain[Max_popsize * 2 + 10];

vector<string> split(const string &s, const string &seperator){
    vector<string> result;
    typedef string::size_type string_size;
    string_size i = 0;

    while(i != s.size()){
        //找到字符串中首个不等于分隔符的字母；
        int flag = 0;
        while(i != s.size() && flag == 0){
            flag = 1;
            for(string_size x = 0; x < seperator.size(); ++x)
                if(s[i] == seperator[x]){
                    ++i;
                    flag = 0;
                    break;
                }
        }

        //找到又一个分隔符，将两个分隔符之间的字符串取出；
        flag = 0;
        string_size j = i;
        while(j != s.size() && flag == 0){
            for(string_size x = 0; x < seperator.size(); ++x)
                if(s[j] == seperator[x]){
                    flag = 1;
                    break;
                }
            if(flag == 0)
                ++j;
        }
        if(i != j){
            result.push_back(s.substr(i, j-i));
            i = j;
        }
    }
    return result;
}

void string2num(string str, double &num)
{
    stringstream ss;
    ss << str;
    ss >> num;
}

class individual
{
    public:

    double dec[count_dec];
    double obj[count_obj];  
    double dec_mat[case_num][outputs_per_case_num];
    double valid;
    double maxobj;
    double meanobj;

    void Cal_obj()
    {
        string solution_string = "";
        for (int i = 0; i < count_dec; i++)
        {
            stringstream ss;
            string str;
            ss << dec[i];
            ss >> str;
            solution_string += str + " ";
        }

        string cmd = simulator_path + output_partens[1] + solution_string + " > " + result_path;
//        string cmd = "dir >" + result_path;
        //string cmd = simulator_path + output_partens[1] + solution_string + " > abc/test.a";
        //string cmd = "dir";
        char *cmd_array = &cmd[0];
        //cout << cmd_array << endl;
        system(cmd_array);
        //cout<<"system return : " << a<<endl;
    }

    void init(){
//        FILE *fp1;
//        fp1 = fopen(result_path.c_str(), "w");
//        if(fp1 == NULL)
//        {
//            cout << result_path << " doesn't exit" << endl;
//        }
//        fclose(fp1);

        Cal_obj();

        //##############################
        bool check_error_code = 1;



        fstream fs(result_path);

        string line;
        valid = 1;
        getline(fs, line);
        // cout << "line: " << line << endl;
        for (int i = 0; i < case_num; i++)
        {

            getline(fs, line);
//            cout << "line: " << line << endl;
            vector<string> objective_value_s = split(line, "\n ");
            if (check_error_code)
            {
                double errorcode0, errorcode1;
                string2num(objective_value_s[0], errorcode0);
                string2num(objective_value_s[1], errorcode1);
                if (errorcode0 != 0 || errorcode1 != 0)
                {
                    // this solution is invalid
                    valid = 0;
                }
            }

            for (int j = 0; j < outputs_per_case_num; j++) //modified at v1.12
            {

                double objective_value = 0.0;
                string2num(objective_value_s[j+4], objective_value);
                dec_mat[i][j] = abs(objective_value - ref_output[i][j]) / ref_output[i][j];
            }
        }
        fs.close();

        // for (int i = 0; i < case_num; i++){
        //     for (int j = 0; j < outputs_per_case_num; j++){
        //         cout << ref_output[i][j] << " ";
        //     }
        //     cout << endl;
        // }

        // for (int i = 0; i < case_num; i++){
        //     for (int j = 0; j < outputs_per_case_num; j++){
        //         cout << dec_mat[i][j] << " ";
        //     }
        //     cout << endl;
        // }
        maxobj = obj[0];
        double sum_obj = 0;
        for (int i = 0; i < case_num; i++){
            for (int j = 0; j < outputs_per_case_num; j++){
                // cout << i * outputs_per_case_num + j << endl;
                obj[i*outputs_per_case_num+j] = dec_mat[i][j];
                if(dec_mat[i][j] > maxobj){
                    maxobj = dec_mat[i][j];
                }
                sum_obj += dec_mat[i][j];
            }
        }
        meanobj = sum_obj / (case_num);

        // cout << "Finish" << endl;

    }
};

individual population[Max_popsize+5];
individual next_population[Max_popsize+5];
individual com_population[Max_popsize*2+20];
individual offspring[Max_popsize+5];
individual newchild, newchild1, newchild2;

// test is ok
void input_param ()
{
    for (int i = 0; i < count_dec; i++)
    {
        lowerbound[i] = lower_bounds[i];
        upperbound[i] = upper_bounds[i];
    }

    pro_crossover = 1;
    pro_mutation = 1.0/count_dec;
    distri_crossover = 20;
    distri_mutation = 20;
    eeta = 20;

    ///////////////////////////////
    fp = fopen(input_files.c_str(), "r");
    if (fp == NULL){
        cout << "path:"<< input_files.c_str() << " doesn't exit"<<endl;
        exit(0);
    }
    fclose(fp);

    std::ifstream i(input_files.c_str());
    json j;
    i >> j;
//    cout<< j << endl;

    id=j["ID"];
    pop_size=j["POPSIZE"];
    seed=j["SEED"];
    pop_size=j["POPSIZE"];
    MAXFE=j["STOP"]["MAXFE"];
    Max_gen=j["STOP"]["MAXITER"];
    Max_time=j["STOP"]["MAXTIME"];
    Max_error=j["STOP"]["MAXERROR"];
    Mean_error=j["STOP"]["MEANERROR"];




    //cout << input_files << endl;
        //printf("%s", input_files[num_f]);

//		while (1)
//		{
//			fscanf(fp, "%s", dummy_string);
//			cout << dummy_string << endl;
//
//			if (strcmp(dummy_string, "\"ID\":") == 0)
//			{
//				fscanf(fp, "%d", &id);
//                // cout << "ID: " << id << endl;
//			}
//			else if (strcmp(dummy_string, "\"type\":") == 0)
//			{
//				fscanf(fp, "%d", &type);
//                cout << "type: " << type << endl;
//			}
//			else if (strcmp(dummy_string, "\"status\":") == 0)
//			{
//				fscanf(fp, "%d", &status);
//                cout << "status: " << status << endl;
//			}
//			else if (strcmp(dummy_string, "\"POPSIZE\":") == 0)
//			{
//				fscanf(fp, "%d", &pop_size);
//                if(pop_size == -1)
//                {
//                    pop_size = pop_size_default;
//                }
//
//                // cout << "popsize: " << pop_size << endl;
//			}
//			else if (strcmp(dummy_string, "\"SEED\":") == 0)
//			{
//				fscanf(fp, "%d", &seed);
//                // cout << "seed: " << seed << endl;
//			}
//            else if (strcmp(dummy_string, "\"STOP\":") == 0)
//			{
//                while(1)
//                {
//                    fscanf(fp, "%s", dummy_string);
//                    // cout << dummy_string << endl;
//                    if(strcmp(dummy_string, "\"MAXFE\":") == 0)
//                    {
//                        fscanf(fp, "%d", &MAXFE);
//                        // cout << "MAXFE: " << MAXFE << endl;
//                        if(MAXFE == -1)
//                        {
//                            MAXFE = MAXFE_default;
//                        }
//                    }
//                    else if (strcmp(dummy_string, "\"MAXITER\":") == 0)
//                    {
//                        fscanf(fp, "%d", &Max_gen);
//                        // cout << "MAXITER: " << Max_gen << endl;
//                        if(Max_gen == -1)
//                        {
//                            Max_gen = Max_gen_default;
//                        }
//                    }
//                    else if (strcmp(dummy_string, "\"MAXTIME\":") == 0)
//                    {
//                        fscanf(fp, "%lf", &Max_time);
//                        // cout << "MAXTIME: " << Max_time << endl;
//                        if(Max_time == -1)
//                        {
//                            Max_time = Max_time_default;
//                        }
//                    }
//                    else if (strcmp(dummy_string, "\"MAXERROR\":") == 0)
//                    {
//                        fscanf(fp, "%lf", &Max_error);
//                        // cout << "MAXERROR: " << Max_error << endl;
//                        if(Max_error == -1)
//                        {
//                            Max_error = Max_error_default;
//                        }
//                    }
//                    else if (strcmp(dummy_string, "\"MEANERROR\":") == 0)
//                    {
//                        fscanf(fp, "%lf", &Mean_error);
//                        // cout << "MEANERROR: " << Mean_error << endl;
//                        if(Mean_error == 1)
//                        {
//                            Mean_error = Mean_error_dafault;
//                        }
//                    }
//                    else if (strcmp(dummy_string, "},") == 0)
//                    {
//                        break;
//                    }
//                }
//
//			}
//
//            else if (strcmp(dummy_string, "}") == 0)
//            {
//                break;
//            }
//
//		}
//		fclose(fp);
//        cout << "success" << endl;
}


// test is ok
void initialization ()
{
    for (int i = 0; i < pop_size; i++)
    {
        for (int j = 0; j < count_dec; j++)
        {
            double rand01 = 1.0 * rand() / RAND_MAX;
            population[i].dec[j] = 1.0*(0.0 + upperbound[j]+lowerbound[j])/2 + 1.0*(0.0+upperbound[j]-lowerbound[j])/2*(1.0*2*rand01 - 1);
        }
        population[i].init ();
    }
}


// test is ok
double cal_dis_SDE(individual pop1, individual pop2)
{
        double res = 0;
    for (int m = 0; m < count_obj; m++){
        if( pop1.obj[m] < pop2.obj[m] ){
            double er = pop1.obj[m] - pop2.obj[m];
            res = res + er*er;
        }
    }
    return sqrt(res);
}


// test is ok
void cal_SDE_fitness (int flag)
{
    if(flag == 1)
    {
        // test is ok
        // the number of individuals calculated is pop_size for selection of parents
        int n = pop_size;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if(i == j)
                    Fitness_mat[i][j] = INF;
                else{
                    // cout << "---------------" << endl;
                    // cout << population[i].obj[0] << ' ' << population[i].obj[1] << endl;
                    // cout << population[j].obj[0] << ' ' << population[j].obj[1] << endl;
                    Fitness_mat[i][j] = cal_dis_SDE(population[i], population[j]);
                    // cout << Fitness_mat[i][j] << ' '  << endl;
                }

            }
        }

        for(int i = 0; i < n; i++)
        {
            fitness_pop[i] = INF;
            for (int j = 0; j < n; j++){
                if(fitness_pop[i] > Fitness_mat[i][j]){
                    fitness_pop[i] = Fitness_mat[i][j];
                }
            }
        }


    }
    else{

        // the number of individuals calculated is 2*pop_size for environmental selection

        for (int i = 0; i < pop_size; i++){
            com_population[i] = population[i];
        }
        for (int i = 0; i < pop_size; i++){
            com_population[i+pop_size] = offspring[i];
        }

        int n = 2 * pop_size;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if(i == j)
                    Fitness_mat[i][j] = INF;
                else{
                    Fitness_mat[i][j] = cal_dis_SDE(com_population[i], com_population[j]);
                }

            }
        }

        for(int i = 0; i < n; i++)
        {
            fitness_all[i] = INF;
            for (int j = 0; j < n; j++){
                if(fitness_all[i] > Fitness_mat[i][j]){
                    fitness_all[i] = Fitness_mat[i][j];
                }
            }
        }

    }
}


// test is ok
void tournament_selection (double* fitness, int n){

    for (int i = 0; i < n; i++){
        int parent1 = floor(1.0 * rand() / RAND_MAX * pop_size);
        int parent2 = floor(1.0 * rand() / RAND_MAX * pop_size);

        if(fitness[parent1] > fitness[parent2]){
            matingpool[i] = parent1;
        }else{
            matingpool[i] = parent2;
        }
        //cout << fitness[parent1] << " " << fitness[parent2] << " " << matingpool[i] << endl;
    }

}


// test is ok
void BubbleSort(double  *fitness1, int length, int * pop_idx)
{
	for (int m = 0; m < length; m++)
	{
		pop_idx[m] = m;
	}

	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length - i - 1; j++)
		{
			if (fitness1[j] < fitness1[j + 1])
			{
                float temp = fitness1[j];
				fitness1[j] = fitness1[j + 1];
				fitness1[j + 1] = temp;

				int ind_temp = pop_idx[j];
				pop_idx[j] = pop_idx[j + 1];
				pop_idx[j + 1] = ind_temp;
			}
		}
	}
    // for (int i = 0; i < length; i++)
    //     cout << fitness1[i] << " " << pop_idx[i] << endl;
}

void mutation(individual *new_pop_ptr)
{

    int i;
    float rnd, delta, indi, deltaq;
    float y, yl, yu, xy, val;

    for (i = 0; i < count_dec; i++)
    {
        rnd = (1.0 * rand() / RAND_MAX);

        /*For each variable find whether to do mutation or not */
        if (rnd <= pro_mutation)
        {
            y = new_pop_ptr->obj[i];
            yl = lowerbound[i];
            yu = upperbound[i];

            if (y > yl)
            {
                /*Calculate delta */

                if ((y - yl) < (yu - y))
                    delta = (y - yl) / (yu - yl);
                else
                    delta = (yu - y) / (yu - yl);

                rnd = (1.0 * rand() / RAND_MAX);

                indi = 1.0 / (distri_mutation + 1.0);

                if (rnd <= 0.5)
                {
                    xy = 1.0 - delta;
                    val =
                        2 * rnd + (1 -2 * rnd) * (pow(xy, (distri_mutation + 1)));
                    deltaq = pow(val, indi) - 1.0;
                }
                else
                {
                    xy = 1.0 - delta;
                    val =
                        2.0 * (1.0 - rnd) + 2.0 * (rnd - 0.5) * (pow(xy, (distri_mutation + 1)));
                    deltaq = 1.0 - (pow(val, indi));
                }

                /*Change the value for the parent */
                //  *ptr  = *ptr + deltaq*(yu-yl);
                // Added by Deb (31/10/01)
                y = y + deltaq * (yu - yl);
                if (y < yl)
                    y = yl;
                if (y > yu)
                    y = yu;
                new_pop_ptr->obj[i] = y;
            }
            else // y == yl
            {
                xy = (1.0 * rand() / RAND_MAX);
                new_pop_ptr->obj[i] = xy * (yu - yl) + yl;
            }
        }
        //  ptr++;
    }
}

void SBXcrossover(individual parent1, individual parent2)
{
    int  j;
    float rnd, par1, par2, chld1, chld2, betaq, beta, alpha;
    float y1, y2, yu, yl, expp;
    /*Loop over no of variables */
    for (j = 0; j < count_dec; j++)
    {
        /*Selected Two Parents */
        par1 = parent1.dec[j];
        par2 = parent2.dec[j];

        yl = lowerbound[j];
        yu = upperbound[j];
        rnd = (1.0 * rand() / RAND_MAX);

        /* Check whether variable is selected or not */
        if (rnd <= 0.5)
        {
            /*Variable selected */
            //ncross++;

            if (fabs(par1 - par2) > 0.000001) // changed by Deb (31/10/01)
            {
                if (par2 > par1)
                {
                    y2 = par2;
                    y1 = par1;
                }
                else
                {
                    y2 = par1;
                    y1 = par2;
                }

                /*Find beta value */
                if ((y1 - yl) > (yu - y2))
                {
                    beta = 1 + (2 * (yu - y2) / (y2 - y1));
                    //printf("beta = %f\n",beta);
                }
                else
                {
                    beta = 1 + (2 * (y1 - yl) / (y2 - y1));
                    //printf("beta = %f\n",beta);
                }

                /*Find alpha */
                expp = eeta + 1.0;

                beta = 1.0 / beta;

                alpha = 2.0 - pow(beta, expp);

                // if (alpha < 0.0)
                // {
                //     printf("ERRRROR %f %d %d %f %f\n", alpha, par1, par2);
                //     exit(-1);
                // }

                rnd = (1.0 * rand() / RAND_MAX);
                ;

                if (rnd <= 1.0 / alpha)
                {
                    alpha = alpha * rnd;
                    expp = 1.0 / (eeta + 1.0);
                    betaq = pow(alpha, expp);
                }
                else
                {
                    alpha = alpha * rnd;
                    alpha = 1.0 / (2.0 - alpha);
                    expp = 1.0 / (eeta + 1.0);
                    if (alpha < 0.0)
                    {
                        printf("ERRRORRR \n");
                        exit(-1);
                    }
                    betaq = pow(alpha, expp);
                }

                /*Generating two children */
                chld1 = 0.5 * ((y1 + y2) - betaq * (y2 - y1));
                chld2 = 0.5 * ((y1 + y2) + betaq * (y2 - y1));
            }
            else
            {

                betaq = 1.0;
                y1 = par1;
                y2 = par2;

                /*Generation two children */
                chld1 = 0.5 * ((y1 + y2) - betaq * (y2 - y1));
                chld2 = 0.5 * ((y1 + y2) + betaq * (y2 - y1));
            }
            // added by deb (31/10/01)
            if (chld1 < yl)
                chld1 = yl;
            if (chld1 > yu)
                chld1 = yu;
            if (chld2 < yl)
                chld2 = yl;
            if (chld2 > yu)
                chld2 = yu;
        }
        else
        {

            /*Copying the children to parents */
            chld1 = par1;
            chld2 = par2;
        }
        newchild1.dec[j] = chld1;
        newchild2.dec[j] = chld2;
    }
}


// test is ok
void production(){

    for (int i = 0; i < pop_size/2; i++){

        individual parent1, parent2;
        parent1 = population[matingpool[2 * i + 0]];
        parent2 = population[matingpool[2 * i + 1]];
        double rnd = (1.0 * rand() / RAND_MAX);
        //cout << rnd << endl;
        if(rnd <= pro_crossover){
            SBXcrossover(parent1, parent2);
        }else{
            newchild1 = parent1;
            newchild2 = parent2;
        }

        mutation(&(newchild1));
        mutation(&(newchild2));
        newchild1.init ();
        newchild2.init ();

        offspring[2 * i + 0] = newchild1;
        offspring[2 * i + 1] = newchild2;
    }
}


// test is ok
void environmentalselection(int fla){

    if(fla == 1)
    {
        // one-time evaluation
        BubbleSort(fitness_all, 2*pop_size, pop_idx);
        for (int i = 0; i < pop_size; i++){
            if(pop_idx[i] >= pop_size){
                next_population[i] = offspring[pop_idx[i] - pop_size];
            }else{
                next_population[i] = population[pop_idx[i]];
            }
        }

        for (int i = 0; i < pop_size; i++){
            population[i] = next_population[i];
        }
    }
    else{

        // dynamic evaluation
        for (int i = 0; i < 2*pop_size; i++){
            remain[i] = 1;
        }

        int worst_one;
        for (int t = 0; t < pop_size; t++)
        {
            // calculate the fitness of remains
            for (int i = 0; i < 2*pop_size; i++)
            {
                if (remain[i] == 1)
                {
                    worst_one = i;
                    double fitness_temp = INF;
                    for (int j = 0; j < 2 * pop_size; j++)
                    {
                        if (remain[j] == 1 && fitness_temp > Fitness_mat[i][j])
                        {
                            fitness_temp = Fitness_mat[i][j];
                        }
                    }
                    fitness_all[i] = fitness_temp;
                }
            }

            // loop: delete the individuals with the smallest fitness
            for (int i = 0; i < 2 * pop_size; i++)
            {
                if (remain[i] == 1)
                {
                    if(fitness_all[worst_one] > fitness_all[i])
                    {
                        worst_one = i;
                    }
                }
            }
            remain[worst_one] = 0;
        }

        int pp = 0;
        for (int i = 0; i < 2*pop_size; i++){
            if(remain[i] == 1){
                if(i >= pop_size){
                    next_population[pp] = offspring[i - pop_size];
                    pp++;
                }else{
                    next_population[pp] = population[i];
                    pp++;
                }
            }

        }

        for (int i = 0; i < pop_size; i++){
            population[i] = next_population[i];
        }
        // for (int i = 0; i < 2*pop_size; i++){
        //     if(remain[i] == 1)
        //         cout << i << endl;
        // }


    }
}

bool isstop(){

    min_meanobj = INF;

    min_maxobj = INF;

    for (int i = 0; i < pop_size; i++)
    {
        if( population[i].valid == 1 && population[i].meanobj < min_meanobj)
        {
            min_meanobj = population[i].meanobj;
            min_meanobj_idx = i;
        }
        if(population[i].valid == 1 && population[i].maxobj < min_maxobj)
        {
            min_maxobj = population[i].maxobj;
            min_maxobj_idx = i;
        }
    }

    // cout << min_meanobj << " " << min_maxobj << endl;
    if(min_meanobj < Mean_error && min_maxobj < Max_error)
    {// 匹配误差 满足
        return true;
    }

    if(timecost >= Max_time)
    {// 时间 满足
        // cout << "error is ok, and time is over" << endl;
        return true;
    }

    if(gen_now >= Max_gen)
    {// 代数 满足
        // cout << "error is ok, and generation is over" << endl;
        return true;
    }
    if(gen_now*pop_size >= MAXFE)
    {// FEs 满足
        // cout << "error is ok, and generation is over" << endl;
        return true;
    }
    return false;
}


void print_popobj ()
{

    fp = fopen("./Results/PopObj.txt", "w");
    for (int i = 0; i < pop_size; i++)
    {
        for (int j = 0; j < count_obj; j++){
            fprintf(fp, "%f ", population[i].obj[j]);
        }
        fprintf(fp, "\n");
    }

    // fprintf(fp, "\n");
    fclose(fp);
    // cout << "\nPrinting objective values\n";
    // for (int i = 0; i < pop_size; i++)
    // {
    //   for (int j = 0; j < count_obj; j++)
    //     cout << i << " " << population[i].obj[j] << " ";
    //   cout << "\n";
    // }
}



void print_off ()
{
  cout << "\nPrinting offspring real values of the function values \n";
  for (int i = 0; i < pop_size; i++)
    {
      for (int j = 0; j < count_obj; j++)
        cout << i << " " << offspring[i].obj[j] << " ";
      cout << "\n";
    }
}

void print_fitnesspop ()
{
  cout << "\nPrinting fitness of population\n";
  for (int i = 0; i < pop_size; i++)
    {
        cout << i << " fitness : " << fitness_pop[i] << endl;
    }
}

void print_fitnessall ()
{
  cout << "\nPrinting fitness of population\n\n";
  for (int i = 0; i < pop_size*2; i++)
    {
        cout << i << " fitness : " << fitness_all[i] << endl;
    }
}

void print_Fitness_mat()
{
    cout << "\nPrinting fitness matrix of population\n";
    for (int i = 0; i < 2*pop_size; i++)
    {
        for (int j = 0; j < 2*pop_size; j++){
            cout << Fitness_mat[i][j] << ' ';
        }
        cout << endl;
    }


}

void print_matingpool()
{
    cout << "\nPrinting mating pool \n";
    for (int i = 0; i < pop_size; i++)
    {
        cout << matingpool[i] << ' '<< endl;
    }


}

void print_outjson(int f){

    if(f == 0){

    }
    else if(f == 1)
    {

        // log
        fp = fopen(tempt_files.c_str(), "w");
        fprintf(fp, "{\n\"SOLUTIONS\":[\n");
        fprintf(fp,"{\"ID\": %d,\n", id);
        fprintf(fp, "\"FROMFE\": %d,\n", pop_size*gen_now);
        fprintf(fp, "\"FROMTIME\": %.4lf,\n", timecost);
        fprintf(fp, "\"MINMAXERROR\": %.4lf,\n", min_maxobj);
        fprintf(fp, "\"AVGERROR\": %.4lf,\n", min_meanobj);

        fprintf(fp, "\"ERRORS\":[");
        for (int i = 0; i < count_obj - 1; i++){
            fprintf(fp, "%.4lf, ", population[min_maxobj_idx].obj[i]);
        }
        fprintf(fp, "%.4lf],\n", population[min_maxobj_idx].obj[count_obj-1]);

        fprintf(fp, "\"VALUES\":[");
        for (int i = 0; i < count_dec - 1; i++){
            fprintf(fp, "%.4lf, ", population[min_maxobj_idx].dec[i]);
        }
        //fprintf(fp, "%.4lf],\n},\n", population[min_maxobj_idx].dec[count_dec-1]);
        fprintf(fp, "%.4lf],\n}\n", population[min_maxobj_idx].dec[count_dec-1]);
        fclose(fp);

        // abstract
        time_t end_time = time(NULL);
        fp = fopen(abstract.c_str(), "w");
        fprintf(fp, "{\n");
        fprintf(fp,"\"ID\": %d,\n", id);
        fprintf(fp,"\"STARTTIME\": %d,\n", start_time);//
        fprintf(fp,"\"CURRENT-FE\": %d,\n", pop_size*gen_now);
        fprintf(fp,"\"CURRENT-ITER\": %d,\n", gen_now);
        if(stop_flag == 0)
        {
            fprintf(fp, "\"STATUS\": %d,\n", 0); // 0 is running ; 1 is stopping
        }
        else
        {
            fprintf(fp, "\"STATUS\": %d,\n", 1); // 0 is running ; 1 is stopping
        }

        fprintf(fp,"\"STOPTIME\": %d\n}\n", end_time);
        fclose(fp);
    }
    else if(f == 2)
    {
        fp = fopen(tempt_files.c_str(), "a");

        fprintf(fp,"\n,\n");

        fprintf(fp,"\n\n{\"ID\": %d,\n", id);
        fprintf(fp, "\"FROMFE\": %d,\n", pop_size*gen_now);
        fprintf(fp, "\"FROMTIME\": %.4lf,\n", timecost);
        fprintf(fp, "\"MINMAXERROR\": %.4lf,\n", min_maxobj);
        fprintf(fp, "\"AVGERROR\": %.4lf,\n", min_meanobj);

        fprintf(fp, "\"ERRORS\":[");
        for (int i = 0; i < count_obj - 1; i++){
            fprintf(fp, "%.4lf, ", population[min_maxobj_idx].obj[i]);
        }
        fprintf(fp, "%.4lf],\n", population[min_maxobj_idx].obj[count_obj-1]);

        fprintf(fp, "\"VALUES\":[");
        for (int i = 0; i < count_dec - 1; i++){
            fprintf(fp, "%.4lf, ", population[min_maxobj_idx].dec[i]);
        }
//        fprintf(fp, "%.4lf],\n},\n", population[min_maxobj_idx].dec[count_dec-1]);
        fprintf(fp, "%.4lf],\n}\n", population[min_maxobj_idx].dec[count_dec-1]);
        fclose(fp);


        // abstract
        time_t end_time = time(NULL);
        fp = fopen(abstract.c_str(), "w");
        fprintf(fp, "{\n");
        fprintf(fp,"\"ID\": %d,\n", id);
        fprintf(fp,"\"STARTTIME\": %d,\n", start_time);//
        fprintf(fp,"\"CURRENT-FE\": %d,\n", pop_size*gen_now);
        fprintf(fp,"\"CURRENT-ITER\": %d,\n", gen_now);
        if(stop_flag == 0)
        {
            fprintf(fp, "\"STATUS\": %d,\n", 0); // 0 is running ; 1 is stopping
        }
        else
        {
            fprintf(fp, "\"STATUS\": %d,\n", 1); // 0 is running ; 1 is stopping
        }
        fprintf(fp,"\"STOPTIME\": %d\n}\n", end_time);
        fclose(fp);
    }

    CopyFile(tempt_files.c_str(),final_files.c_str(), FALSE);//false代表覆盖，true不覆盖
    fp = fopen(final_files.c_str(), "a");
    fprintf(fp, "\n]}");
    fclose(fp);
}
/////////////////-----------------/////////////////-------------------/////////////////-------------------
// EX.exe ..\tasksFolder\id\

int main (int argc,char *argv[])
// int main ()
{
    string path;
    path = argv[1];
    path = path + "/";

    //path = "../tasksFolder/id/";
    input_files = path + input_files;
    tempt_files = path + tempt_files;
    final_files = path + final_files;
    result_path = path + result_path;
    abstract = path + abstract;
//    cout <<  input_files  << endl;
//    cout <<  tempt_files  << endl;
//    cout <<  final_files  << endl;
//    cout <<  result_path  << endl;

    clock_t start,finish;
    start = clock();
    input_param();
    start_time=time(NULL);
    stop_flag = 0;

    initialization();
    cout << "success" << endl;
    //print_popobj();
    srand(seed);
    gen_now = 1;
    isstop();
    finish = clock();
    timecost = (finish - start + 0.0) / CLOCKS_PER_SEC;
    print_outjson(1);
    while(1){
        // cout << "\ngeneration: " << gen_now << " ";

        cal_SDE_fitness(1);
        // print_Fitness_mat();
        // print_fitnesspop();
        tournament_selection(fitness_pop, pop_size);
        // print_matingpool();
        production();
        // print_off();
        cal_SDE_fitness(2);
        // print_popobj();
        // print_off();
        // print_Fitness_mat();
        // print_fitnessall();
        environmentalselection(2);

        ////////////////////
        gen_now += 1;
        finish = clock();
        timecost = (finish - start + 0.0) / CLOCKS_PER_SEC;

        // cout << "Time: " << timecost << endl;
        if(isstop()){
            stop_flag = 1;
            // cout << "OVER" << endl;
        break;
        }
        print_outjson(2);
    }
    print_outjson(2);
    // cout << "--------------end-------------" << endl;
    return 0;
}
