package EngOpt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngOptApplicationTests {

	@Test
	void contextLoads() {
	}

}
