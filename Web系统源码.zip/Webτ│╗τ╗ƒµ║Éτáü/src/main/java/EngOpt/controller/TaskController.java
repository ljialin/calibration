package EngOpt.controller;

import EngOpt.service.TaskService;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.util.Date;

@RestController
@RequestMapping("/Task")
public class TaskController {
    private TaskService taskService;
    static String ImageUploadDir = "";
    static String ImagefinishedDir = "";

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }


    /**
     * 创建task
     *
     * @return JSONObject
     * @throws IOException
     * @input parameters
     */
    @RequestMapping(value = "/Initial", method = RequestMethod.POST)
    public Object initialTask(@RequestParam String timeLimit,
                              @RequestParam String randomSeed,
                              @RequestParam String goalMinmaxError,
                              @RequestParam String goalAvgError,
                              @RequestParam String popSize,
                              @RequestParam String EFLimit,
                              @RequestParam String algorithm,
                              @RequestParam String iterationLimit) {
        System.out.println("--------- Create task request ---------");
        String result = taskService.createTask(timeLimit, randomSeed, goalMinmaxError,goalAvgError,popSize,algorithm,EFLimit,iterationLimit);
        JSONObject jsonObject = new JSONObject();
        if (taskService.isNumeric(result)){
            jsonObject.put("result", "success");
            jsonObject.put("taskID",result);
        }
        else{
            jsonObject.put("result","fail");
            jsonObject.put("message",result);
        }
        System.out.println("JSON "+jsonObject.toString());
        System.out.println( "--------- Create request finish, result " + result + " ---------");
        return jsonObject;

    }




    /**
     * 查询task状态
     *
     * @return JSONObject
     * @throws IOException
     */
    @RequestMapping(value = "/Check", method = RequestMethod.POST)
    public Object checkTask(@RequestParam int taskID) throws IOException {
        System.out.println( "--------- Check task ---------");
        Date date = new Date();
        System.out.println("--- " + date.toString()+" ---");
        JSONObject jsonObject = new JSONObject();
        JSONObject[] taskJsons = taskService.checkTaskLog(taskID);
        if (taskJsons == null) {
            jsonObject.put("result", "fail, try again.");
            return jsonObject;
        }
        jsonObject.put("result","success");
        jsonObject.put("taskAbs",taskJsons[0]);
        jsonObject.put("taskLog",taskJsons[1]);
        date = new Date();
        System.out.println("--- " + date.toString()+" ---");
        System.out.println( "--------- Check task finish, result " + jsonObject.get("result") + " ---------");
        return jsonObject;
    }


    /**
     * 列出所有task的ID，开始时间，状态，参数
     *
     * @return JSONObject
     * @throws IOException
     */
    @RequestMapping(value = "/List", method = RequestMethod.GET)
    public Object listTask() throws IOException {
        System.out.println( "--------- List tasks ---------");
        Date date = new Date();
        System.out.println("--- " + date.toString()+" ---");
        JSONObject jsonObject = new JSONObject();
        JSONObject[] absJsons = taskService.listAllAbs();
        if (absJsons.length == 0 || absJsons == null) {
            jsonObject.put("result", "fail");
            jsonObject.put("message","无可展示任务");
            date = new Date();
            System.out.println("--- " + date.toString()+" ---");
            System.out.println( "--------- List tasks finish, result " + jsonObject.get("message") + " ---------");
            return jsonObject;
        }
        jsonObject.put("result","success");
        jsonObject.put("abstracts",absJsons);
        date = new Date();
        System.out.println("--- " + date.toString()+" ---");
        System.out.println( "--------- List tasks finish, result " + jsonObject.get("result") + " ---------");
        return jsonObject;
    }


    /**
     * 停止task
     *
     * @return JSONObject
     * @throws IOException
     */
    @RequestMapping(value = "/Stop", method = RequestMethod.POST)
    public Object stopTask(@RequestParam int taskID) throws IOException {
        System.out.println( "--------- Stop task ---------");
        Date date = new Date();
        System.out.println("--- " + date.toString()+" ---");

        JSONObject jsonObject = new JSONObject();
        String result = taskService.stopTask(taskID);
        jsonObject.put("result", result);
        date = new Date();
        System.out.println("--- " + date.toString()+" ---");
        System.out.println( "--------- Stop task finish, result " + jsonObject.get("result") + " ---------");
        return jsonObject;
    }

//    /**
//     * 删除task
//     * @throws IOException
//     * @return JSONObject
//     */
//    @RequestMapping(value="/Check",method=RequestMethod.GET)
//    public Object deleteTask(@RequestParam int taskID) throws IOException {
//
//        JSONObject jsonObject = (JSONObject) taskService.deleteTask(taskID);
//        if (jsonObject == null){
//            jsonObject.put("result","error, try again");
//        }
//        return jsonObject;
//    }
//



//
//    /**
//     * 图片下载
//     * @throws IOException
//     * @return JSONObject
//     */
//    @RequestMapping(value="/downloadImage",method=RequestMethod.GET)
//    public Object startTask(@RequestParam(value="downloadPath")String downloadPath,
//                         HttpServletResponse response) throws IOException {
//        //模拟文件，myfile.txt为需要下载的文件
//        //String path = request.getSession().getServletContext().getRealPath("/")+"/pic/"+downloadpath;
//
//        JSONObject jsonObject = new JSONObject();
//
//        String[] dirs = downloadPath.split("/");//ImageUploadDir + downloadPath;
//        String filename =dirs[dirs.length-1];
//        System.out.println(filename);
//        //获取输入流
//        InputStream bis = new BufferedInputStream(new FileInputStream(new File(downloadPath)));
//        //转码，免得文件名中文乱码
////        downloadPath = URLEncoder.encode(downloadPath,"UTF-8");
//        //设置文件下载头
//        response.addHeader("Content-Disposition", "attachment;filename=" + filename);
//        //1.设置文件ContentType类型，这样设置，会自动判断下载文件类型
//        response.setContentType("application/x-download");
//        BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
//        int len = 0;
//        while((len = bis.read()) != -1){
//            out.write(len);
//            out.flush();
//        }
//        out.close();
//        jsonObject.put("result","成功");
//        return jsonObject;
//    }
//
//

}
