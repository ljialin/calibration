package EngOpt.service;



import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


@Service
public class TaskService {

    // TODO modify paths
    static String EAexePath= "fSDE.exe";
    static Map<String, String> AlgorithmPathMap = new HashMap(){
        {
            put("fSDE", "fSDE.exe");
            put("saPSO", "saPSO.exe");
            put("DE", "DE.exe");
        }
    };
    static String paramFilePath = "data/parameters.json";
    static String tasksFolderPath = "data/tasksFolder";

    static Map<Integer, Process> taskID_Process_Map = new HashMap();

    static String[] physicalNames = {
            "压气机效率",
            "风扇内涵压比",
            "风扇外涵压比",
            "风扇内涵效率",
            "风扇外涵效率",
            "高压涡轮效率",
            "低压涡轮效率",
            "外涵压比",
            "内外涵换热系数",
            "喷管推力系数",
            "喷管流量系数",
            "风扇内涵中介机匣压比",
            "低压涡轮进口流道压比",
            "燃烧室燃烧效率",
            "HPT NGVCL",
            "HPT R1CL",
            "LPT NGVCL",
            "LPT R1CL",
            "功率提取",
            "高压轴机械效率",
            "低压轴机械效率",
            "燃烧室压比",
            "涡轮出口机匣压比",
            "内涵流混合压力比",
            "外涵流混合压力比",
            "喷管进口压力比",
            "混合效率",
            "混合设计马赫数"

    };



//    - Data --
//            -- tasksFolder --
//                            -- ID --
//                                            -- ID_abstract.json
//                                            -- ID_log.json
//                                            -- ID_parameters.json
//                            -- ID --
//                                            -- ID_abstract.json
//                                            -- ID_log.json
//                                            -- ID_parameters.json

    public String createTask(String timeLimit,String randomSeed,String goalMinmaxError,String goalAvgError,String popSize,String Algorithm, String EFLimit, String iterationLimit) {
        //System.out.println(System.getProperty("user.dir"));
        String result = "1";
        int first_char = 0;
        Date time = new Date();
        long T;
        int newTaskID;
        do{
            T = time.getTime();
            T %= 9000;
            T += 1000;
            newTaskID = (int)T;
        }
        while(taskIsExistInFile(newTaskID));

        createTaskFolder(newTaskID);

        // make a new parameters file in task folder
        modifyParamFile(Algorithm,newTaskID,timeLimit,randomSeed,goalMinmaxError,goalAvgError,popSize,EFLimit,iterationLimit);

        // run algorithm program
        String cmd =  AlgorithmPathMap.get(Algorithm) + " " + findPath(newTaskID,2);
        System.out.println("run algorithm, cmd: " + cmd);
        Process process;
        try{
            Runtime mt =Runtime.getRuntime();
            process = mt.exec(cmd);
            //Process process = new ProcessBuilder(EAexePath,findPath(newTaskID,2) ).start();

            long pid = process.pid();
            //System.out.println("pid: "+Long.toString(pid)+" \t"+process.info());


            InputStream is = process.getInputStream();
            taskID_Process_Map.put(newTaskID,process);
            //taskID_PID_Map.put(newTaskID,pid);

            //System.out.println("before read： "+result);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            //System.out.println("int = "+reader.read());
            result = reader.readLine();
            //System.out.println("after read： "+result);



            System.out.println("pid: "+Long.toString(pid)+" \t"+process.info());
            is.close();
            reader.close();
        }
        catch(Exception e)
        {
            System.out.println("error occur: " + e.getMessage());
            return e.getMessage();
        }
        if(result==null){
            System.out.println("task create fail");
            return "fail, try again.";
        }
        if(result.equals("success")){
            System.out.println("task create success");
            return String.valueOf(newTaskID);
        }
        else return "fail, try again.";
    }


    public String stopTask(int taskID){
        System.out.println("map " + taskID_Process_Map.toString() );
        if(!taskIsExistInFile(taskID))
            return "该任务不存在";
        if(taskIsStopInAbs(taskID))
            return "任务已停止";
        try{
            Process p = taskID_Process_Map.get(taskID);
            long PID = p.pid();
            String cmd = "taskkill /pid "+Long.toString(PID) + "  -t  -f";
            Process process = Runtime.getRuntime().exec(cmd);
            taskID_Process_Map.remove(taskID);
            changeAbsStatusToStop(taskID);
        }
        catch(Exception e)
        {
            changeAbsStatusToStop(taskID);//无法停止进程，认为其已经终止
            System.out.println(e);
            return "算法进程信息获取有误，已强制停止任务";
        }
        return "success";
    }

    public JSONObject[] checkTaskLog(int taskID) {

        updateMap(taskID);
        String taskLogPath = findPath(taskID,0);
        String logContent = readFile(taskLogPath);
        String taskAbsPath = findPath(taskID,1);
        String absContent = readFile(taskAbsPath);
        try {

            JSONObject logContentJson = JSONObject.parseObject(logContent);

            JSONObject absContentJson = JSONObject.parseObject(absContent);
            JSONObject[] result = {absContentJson,logContentJson};
            return result;
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return null;
    }

    private boolean taskIsExistInFile(int taskID){
        String[] IDs_str = listAllTask();
        for(int i=0;i< IDs_str.length;i++){
            if( Integer.toString(taskID).equals(IDs_str[i]))
                    return true;
        }
        return false;
    }



    private String[] listAllTask() {
        String[] result = scanFolder(tasksFolderPath);
        return result;
    }

    private boolean taskIsStopInAbs(int taskID){

        String absPath = findPath(taskID,1);
        String contect_s = "";
        System.out.println(absPath);
        try {
            contect_s  =  readFile(absPath);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        JSONObject jsonObject = (JSONObject) JSONObject.parse(contect_s);
        if(jsonObject.getInteger("STATUS") == 1)
            return true;
        else
            return false;
    }

    public void changeAbsStatusToStop(int taskID){
        String absPath = findPath(taskID,1);
        String contect_s = "";
        contect_s=readFile(absPath);
        JSONObject jsonObject = (JSONObject) JSONObject.parse(contect_s);
        jsonObject.put("STATUS",1);
        writeFile(absPath, jsonObject.toJSONString());
    }

    private void updateMap(int taskID){
        if(taskIsStopInAbs(taskID))
            taskID_Process_Map.remove(taskID);
    }

    public JSONObject[] listAllAbs(){
        String[] allID_s = listAllTask();
        ArrayList<JSONObject> absJsonArrayList = new ArrayList();

        for(int i=0;i< allID_s.length;i++){
            String absPath = findPath(Integer.valueOf(allID_s[i]),1);
            String contect_s = "";

            contect_s = readFile(absPath);
            if(contect_s == null) continue;
            JSONObject jsonObject = (JSONObject) JSONObject.parse(contect_s);
            absJsonArrayList.add(jsonObject);
        }
        JSONObject[] absJsons= new JSONObject[absJsonArrayList.size()];
        for(int i=0;i<absJsonArrayList.size();i++){
            absJsons[i] = absJsonArrayList.get(i);
        }
        return absJsons;
    }

    private void modifyParamFile(String Algorithm, int taskID, String timeLimit, String randomSeed, String goalMinmaxError, String goalAvgError, String popSize, String EFLimit, String iterationLimit){
        // create a backup parameters file into task folder, no change in origin parameters file

        String newFile = findPath(taskID,3);
        System.out.println("target parameter file path: " + newFile);
        try {
            System.out.println("source parameter file path: " + paramFilePath);
            String paramFileContent = readFile(paramFilePath);
            System.out.println("source parameter file read success");
            JSONObject jsonObject = (JSONObject) JSONObject.parse(paramFileContent);
            JSONObject algoParams = (JSONObject)jsonObject.get(Algorithm);

            JSONObject stopC = (JSONObject)algoParams.get("STOP");
            algoParams.put("ID",taskID);


            if(isNumeric(popSize))
                algoParams.put("POPSIZE", Integer.parseInt(popSize));
            if(isNumeric(randomSeed))
                algoParams.put("SEED", Integer.parseInt(randomSeed));

            if(isNumeric(timeLimit))
                stopC.put("MAXTIME", Double.parseDouble(timeLimit));
            if(isNumeric(goalMinmaxError))
                stopC.put("MAXERROR", Double.parseDouble(goalMinmaxError));
            if(isNumeric(goalAvgError))
                stopC.put("MEANERROR", Double.parseDouble(goalAvgError));
            if(isNumeric(EFLimit))
                stopC.put("MAXFE", Integer.parseInt(EFLimit));
            if(isNumeric(iterationLimit))
                stopC.put("MAXITER", Integer.parseInt(iterationLimit));
            jsonObject.put("STOP",stopC);

            //System.out.println("params: "+ jsonObject.toString());
            writeFile(newFile, algoParams.toString());
            System.out.println("parameter file modify success");
        }
        catch (Exception e){
            System.out.println("parameter file modify fail: " + e.getMessage());
        }
    }

    public static boolean isNumeric(String str){// source: https://blog.csdn.net/qq_31939617/article/details/88312080
        for(int i=0;i<str.length();i++){

            if(!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
   }

    private void modifyAbstractFile(int taskID, String stopTime, double bestResult){
        String paramFileContent = readFile(findPath(taskID, 1));
        JSONObject jsonObject = (JSONObject) JSONObject.parse(paramFileContent);
        jsonObject.put("stopTime",stopTime);
        jsonObject.put("bestResult",bestResult);
        writeFile(paramFilePath,jsonObject.toString());
    }

    private String findPath(int taskID, int type){// type; 0-log, 1-abstract, 2-taskfloder, 3-param_backup
        String path = System.getProperty("user.dir")+"/data/tasksFolder";
        //System.out.println("system path1 "+path);
        path = path.replace('\\','/');
        //System.out.println("system path2 "+path);
        //String path = tasksFolderPath;
        path += "/" + Integer.toString(taskID) +'/';
        switch (type) {
            case 0: path+= "log.json";
                break;
            case 1: path+=  "abstract.json";
                break;
            case 2: break;
            case 3: path+= "parameters.json";
                break;
        }
        return path;

    }

    private static void writeFile(String filename, String content) {
        try {
            File file = new File(filename);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWritter = new FileWriter(filename);
            fileWritter.write(content);
            fileWritter.close();
            System.out.println("parameter file write success");
        } catch (IOException e) {
            System.out.println("parameter file write fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String readFile (String fileName) {
        String str = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);

            Reader reader = new InputStreamReader(new FileInputStream(jsonFile), "utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            str = sb.toString();
            return str;
        } catch (IOException e) {
            return null;
        }
    }

    private static String[] scanFolder(String logFolderPath){
        File[] files = new File(logFolderPath.toString()).listFiles();
        ArrayList<String> AL = new ArrayList();
        for(int i=0;i<files.length;i++){
            if( files[i].isDirectory()){
                AL.add(files[i].getName());
            }
        }
        String[] result = new String[AL.size()];
        for(int i=0;i<AL.size();i++){
            result[i] = AL.get(i);
        }
        return result;
    }

    private static void createTaskFolder(int taskID){
        File folder = new File(tasksFolderPath+'/'+(Integer.toString(taskID)));
        if(!folder.exists()){//如果文件夹不存在
            folder.mkdir();//创建文件夹
        }
    }

    static void copyFile(String srcPathStr, String desPathStr)// code source https://blog.csdn.net/weixin_42014622/article/details/82959678
    {
        //获取源文件的名称
        String newFileName = srcPathStr.substring(srcPathStr.lastIndexOf("/")+1); //目标文件地址
        System.out.println("源文件:"+newFileName);
        desPathStr = desPathStr + File.separator + newFileName; //源文件地址
        System.out.println("目标文件地址:"+desPathStr);
        try
        {
            FileInputStream fis = new FileInputStream(srcPathStr);//创建输入流对象
            FileOutputStream fos = new FileOutputStream(desPathStr); //创建输出流对象
            byte datas[] = new byte[1024*8];//创建搬运工具
            int len = 0;//创建长度
            while((len = fis.read(datas))!=-1)//循环读取数据
            {
                fos.write(datas,0,len);
            }
            fis.close();//释放资源
            fis.close();//释放资源
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}

