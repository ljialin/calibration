
var CurrentTaskID;
var FinishedTaskNumber;
var RunningTaskNumber;
var isInitializing;

var taskAbss = new Array();
var valueInfo =new Array(
    "压气机效率",
    "风扇内涵压比",
    "风扇外涵压比",
    "风扇内涵效率",
    "风扇外涵效率",
    "高压涡轮效率",
    "低压涡轮效率",
    "外涵压比",
    "内外涵换热系数",
    "喷管推力系数",
    "喷管流量系数",
    "风扇内涵中介机匣压比",
    "低压涡轮进口流道压比",
    "燃烧室燃烧效率",
    "HPT NGVCL",
    "HPT R1CL",
    "LPT NGVCL",
    "LPT R1CL",
    "功率提取",
    "高压轴机械效率",
    "低压轴机械效率",
    "燃烧室压比",
    "涡轮出口机匣压比",
    "内涵流混合压力比",
    "外涵流混合压力比",
    "喷管进口压力比",
    "混合效率",
    "混合设计马赫数"
);
var valueName = new Array(
    "ds_e253",
    "ds_P21q2",
"ds_P13q2",
"ds_e221",
"ds_e213",
"ds_e444",
"ds_e455",
"ds_P16q13",
"ds_ECoreByp",
"ds_CFG8",
"ds_ang8Ds",
"ds_P25q21",
"ds_P45q44_r",
"ds_e34ds",
"ds_HPTWCLN1",
"ds_HPTWCLR1",
"ds_LPTWCLN1",
"ds_LPTWCLR1",
"ds_pwx",
"ds_e_mech_H",
"ds_e_mech_L",
"ds_P4q3",
"ds_P6q5",
"ds_P63q6ds",
"ds_P163q16ds",
"ds_P8q64",
"ds_e_mix",
"ds_XM64_ds"
)
var featureName = new Array(
    "odo_W2",
    "odo_WF",
    "odo_T5",
    "odo_P3",
    "odo_T3",
    "odo_P21",
    "odo_P13",
    "odo_T21",
    "odo_T13",
    "odo_P44",
    "odo_P5",
    "odo_P16",
    "odo_T16",
    "odo_FN",
    "odo_A8"
)

var goalFeature = new Array(
    35.11, 0.38, 906.07, 1493, 731.5, 230.41, 245.15, 405.44, 416.6, 473.2, 170.93, 229.99, 420.87, 20.35, 0.144,
31.99, 0.27, 793.67, 1221, 668.35, 205.6, 217.73, 380.32, 389.07, 384.11, 141.31, 204.79, 392.78, 15.75, 0.144,
28.85, 0.22, 750.9, 1056, 638.96, 185.62, 196.29, 369.03, 379.2, 332.3, 124.53, 183.19, 382.28, 12.76, 0.144,
24.1, 0.16, 694.69, 829, 599.51, 155.63, 163.36, 350.48, 358.55, 260.81, 104.69, 153.42, 362.69, 8.89, 0.144,
21.28, 0.13, 655.64, 702, 569.94, 138.26, 144.36, 338.98, 344.88, 221.94, 95.87, 135.36, 348.96, 6.87, 0.144,
15.75, 0.09, 592.29, 508.45, 515.29, 91.18, 96.12, 295.19, 302.42, 159.83, 59.24, 90.23, 306.18, 3.43, 0.144,
29.08, 0.3, 869.56, 1202.43, 706.33, 187.16, 198.93, 392.52, 403.78, 380.98, 137.54, 187.3, 406.65, 14.22, 0.144,
22.67, 0.16, 710.94, 801.38, 613.37, 144.28, 152.22, 355.07, 364.83, 252.47, 95.17, 142.49, 368.51, 7.73, 0.144,
20.18, 0.19, 803.74, 801.89, 652.24, 124.48, 132.75, 359.62, 370.37, 255.08, 91.14, 125.07, 374.08, 9.27, 0.144,
17.11, 0.12, 691.66, 601.79, 584.66, 104.01, 110.16, 334.18, 343.6, 190.42, 70.2, 103.49, 346.27, 6.07, 0.144,
13.71, 0.08, 632.3, 449.76, 548.13, 84.09, 88.25, 319.62, 325.83, 142.07, 55.52, 82.65, 328.14, 4.02, 0.144,
15.21, 0.07, 582.28, 451.94, 537.94, 97.85, 102.28, 326.72, 333.57, 142.42, 56.76, 95.5, 336.87, 2.13, 0.144,
16.55, 0.09, 616.66, 517.56, 557.65, 105.95, 111.2, 335.73, 341.61, 162.19, 63.01, 103.77, 344.64, 2.96, 0.144,
18.95, 0.12, 682.8, 648, 599.98, 120.87, 127.12, 351.53, 359.66, 203.38, 76.76, 119.22, 363.1, 4.83, 0.144,
11.83, 0.15, 947.26, 526.28, 716.1, 75.06, 80.32, 381.21, 392.62, 168.67, 59.37, 75.89, 398.5, 6.03, 0.144,
11.85, 0.1, 760.3, 448.35, 617.13, 71.79, 76.62, 342.15, 352.51, 142.71, 51.39, 71.94, 355.55, 4.54, 0.144,
10.89, 0.09, 732.31, 400.19, 596.9, 66.02, 70.31, 334.25, 343.99, 126.95, 46.34, 65.84, 347.9, 4.05, 0.144,
12.32, 0.13, 899.76, 512.05, 705.97, 80.42, 85.28, 392.51, 402.85, 164.49, 58.93, 80.51, 408.16, 4.89, 0.144,
11.63, 0.1, 825.66, 450.63, 665.9, 74.5, 78.97, 375.28, 384.56, 143.65, 52.31, 74.47, 389.98, 4.14, 0.144,
9.91, 0.08, 787.41, 368.01, 639.12, 63.58, 67.51, 365.85, 375.07, 116.79, 43.18, 63.1, 378.01, 3.19, 0.144,
21.71, 0.11, 633.42, 660.07, 597.3, 151.81, 158.25, 372.25, 379.73, 206.96, 83.03, 147.19, 381.82, 2.8, 0.144,
27.9, 0.21, 776.99, 1001.9, 678.15, 191.13, 201.21, 403.01, 411.2, 314.73, 120.63, 187.58, 415.68, 6.92, 0.144,
32.48, 0.28, 845.22, 1250.88, 716.54, 222.36, 235.11, 417.08, 428.42, 393.37, 148.03, 220.81, 433.18, 9.8, 0.144,
22.64, 0.28, 1057.8, 1002.46, 857.59, 165.43, 175.92, 493.12, 503.45, 321.08, 117.9, 164.96, 509.05, 8.1, 0.144,
20.33, 0.22, 981.94, 850.4, 813.8, 148.58, 157.14, 473.03, 484.03, 270.45, 101.3, 147.24, 490.86, 6.37, 0.144,
17.9, 0.16, 907.19, 700.24, 771.53, 130.55, 137.87, 455.34, 465.86, 222.67, 84.82, 129.16, 472.82, 4.77, 0.144,
17.99, 0.16, 789.47, 699.51, 648.46, 111.74, 118.37, 359.5, 369.48, 222.28, 79.98, 111.58, 374.38, 6.83, 0.144,
16.29, 0.13, 734.98, 598.43, 614.41, 100.7, 106.29, 347.36, 356.11, 189.71, 69.4, 100.2, 361.06, 5.52, 0.144,
14.48, 0.1, 680.8, 498.58, 581.33, 89.55, 94.45, 335.64, 342.63, 157.03, 58.46, 88.22, 346.66, 4.03, 0.144,
18.31, 0.11, 683.88, 598.92, 615.82, 123.34, 129.44, 371.68, 378.89, 188.35, 73.11, 120.51, 382.53, 3.48, 0.144,
22.12, 0.16, 758.92, 799.3, 660.77, 148.31, 155.7, 388.32, 397.25, 251.59, 95.03, 145.84, 400.28, 5.7, 0.144,
27.44, 0.26, 873.13, 1100.82, 724.09, 183.78, 195.4, 414.25, 424.46, 348.86, 128.09, 182.86, 431.25, 9.33, 0.144,
29.96, 0.23, 836.09, 1098.61, 736.85, 217.58, 228.27, 444.73, 453.47, 346.43, 133.84, 213.87, 456.58, 6.72, 0.144,
33.35, 0.3, 892.24, 1300.07, 766.15, 242.33, 255.55, 455.12, 466, 409.96, 156.47, 239.04, 470.42, 8.74, 0.144,
36.66, 0.37, 948.34, 1500.92, 798.66, 265.57, 280.69, 467.79, 481.34, 474.5, 178.7, 262.62, 485.61, 10.9, 0.144,
34.82, 0.23, 822.27, 1201.48, 756.56, 274.35, 285.69, 478.62, 485.37, 378.13, 152.41, 266.2, 490.32, 5.29, 0.144,
44.48, 0.43, 983.53, 1797.57, 847.25, 345.58, 363.15, 511.56, 524.03, 567.16, 219.1, 340.2, 527.82, 10.83, 0.144

)

var physicalNames = new Array(
    "压气机效率",
    "风扇内涵压比",
    "风扇外涵压比",
    "风扇内涵效率",
    "风扇外涵效率",
    "高压涡轮效率",
    "低压涡轮效率",
    "外涵压比",
    "内外涵换热系数",
    "喷管推力系数",
    "喷管流量系数",
    "风扇内涵中介机匣压比",
    "低压涡轮进口流道压比",
    "燃烧室燃烧效率",
    "HPT NGVCL",
    "HPT R1CL",
    "LPT NGVCL",
    "LPT R1CL",
    "功率提取",
    "高压轴机械效率",
    "低压轴机械效率",
    "燃烧室压比",
    "涡轮出口机匣压比",
    "内涵流混合压力比",
    "外涵流混合压力比",
    "喷管进口压力比",
    "混合效率",
    "混合设计马赫数"
)
var myChart1;
var myChart2;
var myChart3;
var myChart4;
var height = window.screen.height;



window.onload=function () {
    clockUpdate();
    setInterval(clockUpdate, 1000);
    setInterval(autoRefresh, 2000);
    var _html = document.getElementsByTagName('html')[0];
    _html.style.fontSize = height/720 * 12 + 'px';
    // alert(view_width);
    isInitializing=0;
    //获取弹窗按钮
    var btn=document.getElementById("initBtn");
    var myMask=document.getElementById("myMask");
    var myPopWindow = document.getElementById("myPopWindow");

    CurrentTaskID=-1;
    RunningTaskNumber = 0;
    FinishedTaskNumber = 0;


    //按钮绑定事件
    btn.onclick=function () {
        //获取弹窗
        myMask.style.display="block";
    }

    //用户点击其他地方关闭弹窗
    window.onclick=function (event) {
        if(event.target == myMask && isInitializing==0){
            myMask.style.display="none";
        }
    }


    var ctx1 = document.getElementById('timeAvgErrorChart');
    myChart1 = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: [1,2,3,4,5],
            datasets: [{
                label: '时间-标准误差',
                data: [0,0,0,0,0],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132,1)',
                ],
                borderWidth: 1
            }]
        },
        // options: {
            // scales: {
            //     yAxes: [{
            //         ticks: {
            //             beginAtZero: false
            //         }
            //     }]
            // }

        // }

        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });

    var ctx2 = document.getElementById('timeMinmaxErrorChart');
    myChart2 = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: [1,2,3,4,5],
            datasets: [{
                label: '时间-minmax误差',
                data: [0,0,0,0,0],
                backgroundColor: [
                    'rgba(148,0,211, 0.2)'
                ],
                borderColor: [
                    'rgba(148,0,211, 1)'
                ],
                borderWidth: 1
            }]
        },
        // options: {
        //     scales: {
        //         yAxes: [{
        //             ticks: {
        //                 beginAtZero: false
        //             }
        //         }]
        //     }
        // }
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });

    var ctx3 = document.getElementById('EFAvgErrorChart');
    myChart3 = new Chart(ctx3, {
        type: 'line',
        data: {
            labels: [1,2,3,4,5],
            datasets: [{
                label: '仿真次数-标准误差',
                data: [0,0,0,0,0],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                ],
                borderWidth: 1
            }]
        },
        // options: {
        //     scales: {
        //         yAxes: [{
        //             ticks: {
        //                 beginAtZero: false
        //             }
        //         }]
        //     }
        // }
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });

    var ctx4 = document.getElementById('EFMinmaxErrorChart');
    myChart4 = new Chart(ctx4, {
        type: 'line',
        data: {
            labels: [1,2,3,4,5],
            datasets: [{
                label: '仿真次数-minmax误差',
                data: [0,0,0,0,0],
                backgroundColor: [
                    'rgba(148,0,211, 0.2)'
                ],
                borderColor: [
                    'rgba(148,0,211, 1)'
                ],
                borderWidth: 1
            }]
        },
        // options: {
        //     scales: {
        //         yAxes: [{
        //             ticks: {
        //                 beginAtZero: false
        //             }
        //         }]
        //     }
        // }
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });


    refleshList();
}



refleshTask = function(ob){
    <!-- 从后端请求数据-->
    var xhttp = new XMLHttpRequest();
    var myObj;

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            myObj = JSON.parse(this.responseText);

            if (myObj.result == "fail, try again.") {
                alert("失败，未知原因");
            } else {
                <!-- 更新前端页面 -->
                var solution = myObj.taskLog.SOLUTIONS[myObj.taskLog.SOLUTIONS.length - 1].VALUES;

                var errors = myObj.taskLog.SOLUTIONS[myObj.taskLog.SOLUTIONS.length - 1].ERRORS;
                var valueTable = document.getElementById("valueTable");
                var errorsTable = document.getElementById("errorTable");
                // refresh value table
                valueTable.innerHTML="";
                for (var i = 0; i < solution.length; i++) {

                    var tr = document.createElement("tr");

                    var td1 = document.createElement("td");
                    td1.innerHTML=i+1;
                    tr.appendChild(td1);

                    var td2 = document.createElement("td");
                    td2.innerHTML = "<a data-toggle=\"popover\" data-placement=\"bottom\" data-trigger=\"hover\"" + " id=\""
                        + i
                        + "\">"
                        + valueName[i]
                        + "</a>"
                    tr.appendChild(td2);

                    var td3 = document.createElement("td");
                    td3.innerText = solution[i];
                    tr.appendChild(td3);


                    valueTable.appendChild(tr);
                }
                errorsTable.innerHTML = "";

                // refresh error table
                for (var i = 0; i < errors.length; i++) {

                    var tr = document.createElement("tr");

                    var td1 = document.createElement("td");

                    td1.innerHTML = "<a data-toggle=\"popover\" data-placement=\"bottom\" data-trigger=\"hover\"" + " id=\""
                        + (100 + i)
                        + "\">"
                        + parseInt("" + ((i) / 15 + 1)) + "_" + parseInt("" + ((i) % 15 + 1))
                        + "</a>"

                    tr.appendChild(td1);


                    var td3 = document.createElement("td");
                    td3.innerText = goalFeature[i];
                    tr.appendChild(td3);

                    var td2 = document.createElement("td");
                    td2.innerText = Math.floor(errors[i] * 100000) / 1000;
                    tr.appendChild(td2);


                    errorsTable.appendChild(tr);
                }

                // refresh abs area
                var item = myObj.taskAbs;

                document.getElementById("idInAbs").innerText = item.ID;

                document.getElementById("algorithmInAbs").innerText = item.ALGORITHM;

                var d = new Date(item.STARTTIME * 1000 - new Date().getTimezoneOffset() * 60 * 1000);
                var d_s = d.toISOString();
                document.getElementById("startTimeInAbs").innerText = d_s.substr(0, 10) + ' ' + d_s.substr(11, 8);

                var diff = (item.STOPTIME - item.STARTTIME);
                document.getElementById("runningTimeInAbs").innerText = diff + "秒";

                document.getElementById("EFInAbs").innerText = item.CURRENTFE;

                switch (item.STATUS) {
                    case 0:
                        document.getElementById("statusInAbs").innerText = "正在优化";
                        break;
                    case 1:
                        document.getElementById("statusInAbs").innerText = "优化结束";
                        break;
                    default:
                        document.getElementById("statusInAbs").innerText = "未知";
                }

                var minmaxEror = myObj.taskLog.SOLUTIONS[myObj.taskLog.SOLUTIONS.length - 1].MINMAXERROR;
                document.getElementById("minmaxErrorInAbs").innerText = Math.floor(minmaxEror * 100000) / 1000 + "%";

                var standardEror = myObj.taskLog.SOLUTIONS[myObj.taskLog.SOLUTIONS.length - 1].AVGERROR;
                document.getElementById("standardErrorInAbs").innerText = standardEror;





                // 画图
                var EFS = new Array();
                var TimeS = new Array();
                var AvgErrorS = new Array();
                var MinmaxErrorS = new Array();
                for (var x = 0; x < myObj.taskLog.SOLUTIONS.length; x++) {
                    EFS[x] = myObj.taskLog.SOLUTIONS[x].FROMFE;
                    TimeS[x] = myObj.taskLog.SOLUTIONS[x].FROMTIME;
                    AvgErrorS[x] = myObj.taskLog.SOLUTIONS[x].AVGERROR;
                    MinmaxErrorS[x] = myObj.taskLog.SOLUTIONS[x].MINMAXERROR;
                }


                myChart1.data.labels = TimeS;
                myChart1.data.datasets[0].data = AvgErrorS;
                myChart1.update();


                myChart2.data.labels = TimeS;
                myChart2.data.datasets[0].data = MinmaxErrorS;
                myChart2.update();


                myChart3.data.labels = EFS;
                myChart3.data.datasets[0].data = AvgErrorS;
                myChart3.update();

                myChart4.data.labels = EFS;
                myChart4.data.datasets[0].data = MinmaxErrorS;
                myChart4.update();

                $(function infoBox () {
                    $("[data-toggle='popover']").popover({
                        html : true,
                        backgroundColor:'#111',
                        delay:{show:300, hide:500},
                        content: function() {
                            return content(this.id);
                        }
                    });
                });
            }
        }

    };
    var values;


    if (ob.id == "reflashTaskButton") {
        values = "taskID=" + CurrentTaskID;
    } else {
        values = "taskID=" + this.id;
        CurrentTaskID = this.id;
    }



    // var values = "taskID=" + 7948;
    xhttp.open("POST", "/Task/Check", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    if (CurrentTaskID == -1)
        alert("请先选择一个任务")
    else
        xhttp.send(values);

}

function autoRefresh()
{
    // var date = new Date();
    var flag = document.getElementById("autoRefreshFlag").checked;
    // console.log("refresh", date, flag);
    if (flag && CurrentTaskID != -1)
    {
        var ob = document.getElementById("reflashTaskButton");
        refleshTask(ob);
        // console.log("refresh", date);
    }
}

refleshList = function(){

    RunningTaskNumber = 0;
    FinishedTaskNumber = 0;

    <!-- 从后端请求数据-->
    var xhttp = new XMLHttpRequest();
    var myObj;
    xhttp.onreadystatechange = function()  {
        if (this.readyState == 4 && this.status == 200) {
            myObj =  JSON.parse(this.responseText);

            if(myObj.result=="fail"){
                alert(myObj.message);
            }
            else {
                <!-- 更新前端页面 -->
                var listDiv = document.getElementById("taskList");
                listDiv.remove();
                var newListDiv = document.createElement("div");
                newListDiv.setAttribute("class", "my-scrollable  shadow mb-4  ");
                newListDiv.setAttribute("id", "taskList");
                newListDiv.setAttribute("style", "height:950px;background-color: #EEEEEE");
                document.getElementById("taskList-parent").appendChild(newListDiv);

                myObj.abstracts.forEach(displayInList);
                taskAbss = myObj.abstracts;

                document.getElementById("totalTaskNumber").innerText = RunningTaskNumber + FinishedTaskNumber;
                document.getElementById("runningTaskNumber").innerText = RunningTaskNumber;
            }
        }
    };
    xhttp.open("GET", "/Task/List", true);
    xhttp.send();


}

function displayInList(item){


    // <div class="card mb-3 border-bottom-dark">
    //     <div class=" card-header align-items-center justify-content-between">
    //         <span> <span class="font-weight-bold text-dark">ID: 1234</span> &nbsp; 误差0.12% &nbsp;</span>
    //         <span class="align-content-end"><i class="fas fa-toggle-on fa-lg" style="color: green"></i></span>
    //     </div>
    // </div>
    //
    // <div class="card mb-3 border-bottom-dark">
    //     <div class=" card-header align-items-center justify-content-between">
    //         <span> <span class="font-weight-bold text-dark">ID: 1234</span> &nbsp; 误差0.12% &nbsp; </span>
    //         <span class="align-content-end"><i class="fa fa-spinner fa-spin fa-lg fa-fw"></i></span>
    //     </div>
    // </div>

    //alert(RunningTaskNumber);
    var listDiv = document.getElementById("taskList");



    var taskAbsDiv = document.createElement("div");
    taskAbsDiv.addEventListener("click",refleshTask);
    taskAbsDiv.setAttribute("class","card-header align-items-center justify-content-between p-2")


    var div1 = document.createElement("div");


    var statusIcon = document.createElement("i");
    var iconSpan =   document.createElement("span");
    if(item.STATUS == 0) {
        statusIcon.setAttribute("class", " fa fa-spinner fa-spin fa-lg fa-fw");
        statusIcon.setAttribute("style","color: #4e73df")
        RunningTaskNumber += 1;
    }
    else {
        statusIcon.setAttribute("class", "fas fa-check-circle fa-lg");
        statusIcon.setAttribute("style","color: green");
        FinishedTaskNumber += 1;

    }

    iconSpan.appendChild(statusIcon)
    div1.appendChild(iconSpan);
    taskAbsDiv.appendChild(div1);

    var idSpan = document.createElement("span");
    idSpan.setAttribute("class","font-weight-bold text-dark");
    idSpan.innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+"ID:" + item.ID+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    div1.appendChild(idSpan);

    var algorithmSpan = document.createElement("span");
    algorithmSpan.innerText=item.ALGORITHM;
    div1.appendChild(algorithmSpan);



    var div2 = document.createElement("div");

    // var errorSpan = document.createElement("span");
    // errorSpan.innerText="标准误差: " ;
    // div2.appendChild(errorSpan);
    taskAbsDiv.appendChild(div2);


    var div3 = document.createElement("div");
    var startTimeSpan = document.createElement("span");
    var d = new Date(item.STARTTIME*1000 - new Date().getTimezoneOffset()*60*1000);
    var d_s = d.toISOString();
    startTimeSpan.innerHTML="开始时间："+d_s.substr(0, 10) + ' ' + d_s.substr(11, 8);
    div3.appendChild(startTimeSpan);
    taskAbsDiv.appendChild(div3);

    taskAbsDiv.setAttribute("id",""+item.ID);
    var card_div = document.createElement("div");
    card_div.setAttribute("class","card mb-3 border-bottom-dark m-2");
    card_div.appendChild(taskAbsDiv);
    listDiv.appendChild(card_div);
}

stopTask = function() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            myObj = JSON.parse(this.responseText);
            var message;
            message = myObj.result;
            alert(message);
            refleshList();
        }
    };

    if (CurrentTaskID == -1)
        alert("请先选择一个任务")
    else
    {
        var values = "taskID=" + CurrentTaskID;
        xhttp.open("POST", "/Task/Stop", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(values);
    }
}

function initialization(){
    document.getElementById("createBtn").setAttribute("disabled", true);//设置不可点击
    document.getElementById("createBtn").style.backgroundColor  = '#555555';//设置背景色
    document.getElementById("new").innerHTML="</span>正在初始化，请勿进行其他操作</span>\n" +
        "<span class=\"align-content-end\"><i class=\"fa fa-spinner fa-spin fa-lg fa-fw\"></i></span>";

    isInitializing=1;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()  {
        if (this.readyState == 4 && this.status == 200) {
            myObj =  JSON.parse(this.responseText);
            var message;
            if (myObj.result == "fail")
                message = myObj.message;
            else
                // message=myObj.result+", task ID is: "+myObj.taskID;
                message = "创建成功，新的任务ID为： "+myObj.taskID;
            alert(message);
            document.getElementById("new").innerHTML=message;
            document.getElementById("createBtn").removeAttribute("disabled");//去掉不可点击
            document.getElementById("createBtn").style.backgroundColor='#4e73df';
            isInitializing=0;
            refleshList();

        }
    };
    var values = "timeLimit=" + document.getElementById("timeLimit").value.toString();
    values += "&randomSeed=" + document.getElementById("randomSeed").value.toString();
    values += "&EFLimit=" + document.getElementById("EFLimit").value.toString();
    values += "&goalMinmaxError=" + document.getElementById("goalMinmaxError").value.toString();
    values += "&goalAvgError=" + document.getElementById("goalAvgError").value.toString();
    values += "&popSize=" + document.getElementById("popSize").value.toString();
    values += "&iterationLimit=" + document.getElementById("iterationLimit").value.toString();

    values += "&algorithm=" + document.getElementById("selectedAlgorithm").value.toString();
    xhttp.open("POST", "/Task/Initial", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(values);

}


// toturial display
displayTutorial = function (ob){
    // document.getElementById('demo1').style.display='none';
    // document.getElementById("toturialTitle").innerText = "创建任务教程";
    // var contentarea = document.getElementById("tutorialContent");
    //
    // var div1 = document.createElement('div');
    // var line1  = document.createElement('div');
    // line1.innerText = "点击进入控制面板界面";
    // div1.appendChild(line1);
    // var img1 = document.createElement('img');
    // img1.setAttribute('src',"img/1.jpg");
    // div1.appendChild(img1);
    // contentarea.appendChild(div1);


    document.getElementById("demo_create").style.display="none";
    document.getElementById("demo_check").style.display="none";
    document.getElementById("demo_stop").style.display="none";
    document.getElementById("demo_"+ob.id).style.display="block";
    document.getElementById("create").style.color="#fff";
    document.getElementById("check").style.color="#fff";
    document.getElementById("stop").style.color="#fff";
    document.getElementById(ob.id).style.color='#000';
    console.log(ob.id);
    switch (ob.id){
        case "create":{
            document.getElementById("tutorialTitle").innerText="创建任务操作顺序";
            break;
        }
        case "check":{
            document.getElementById("tutorialTitle").innerText="查询任务操作顺序";
            break;
        }
        case "stop":{
            document.getElementById("tutorialTitle").innerText="停止任务操作顺序";
            break;
        }
    }
}

//clock


function clockUpdate() {
    var date = new Date();
    $('.digital-clock').css({'color': '#000','font': '50px/60px \'DIGITAL\', Helvetica;'});
    function addZero(x) {
        if (x < 10) {
            return x = '0' + x;
        } else {
            return x;
        }
    }

    var year = date.getFullYear();
    var month  = addZero(date.getMonth() + 1);
    var day = addZero(date.getDate());
    var weekday = date.getDay();
    var h = addZero(date.getHours());
    var m = addZero(date.getMinutes());
    var s = addZero(date.getSeconds());

    var wd;
    switch (weekday) {
        case 0: wd = '日'; break;
        case 1: wd = '一'; break;
        case 2: wd = '二'; break;
        case 3: wd = '三'; break;
        case 4: wd = '四'; break;
        case 5: wd = '五'; break;
        case 6: wd = '六'; break;
    }
    var time = h + ':' + m + ':' + s
    time = time.replaceAll('1', ' 1');
    // console.log('123   ', time)
    $('.digital-clock').text(time);
    $('.digital-clock-day').text( year + '年' + month + '月' + day + '日 ' + '星期' + wd);
}



// 悬浮信息窗
$(function infoBox () {
    $("[data-toggle='popover']").popover({
        html : true,
        backgroundColor:'#111',
        delay:{show:300, hide:500},
        content: function() {
            return content(this.id);
        }
    });
});
//模拟动态加载标题(真实情况可能会跟后台进行ajax交互)


//模拟动态加载内容(真实情况可能会跟后台进行ajax交互)
function content(id) {
    var data= "";

    if(id<1000) {

        if(id<100)
            data = $("<span>" + valueInfo[id] + "</span>");
        else{
            data = $("<span>参考点 "+parseInt((id-100)/15 +1) + "<br>性能指标 "+((id - 100)%15+1)+"<br>名称： "+ featureName[(id - 100)%15] + "</span>");
        }

    }


    else {
        for(var c = 0;c<taskAbss.length;c++){
            if (taskAbss[c].id == id){
                var time = (taskAbss[c].STOPTIME - taskAbss[c].STARTTIME)+" 秒";
                var S;
                switch (taskAbss[c].STATUS) {
                    case 0:
                        S = "正在优化";
                        break;
                    case 1:
                        S = "优化结束";
                        break;
                    default:
                        S = "未知";
                }
                    data =
                        "<div class=\"row\">\n" +
                        "\n" +
                        "                          <div class=\"col-6\">\n" +
                        "                            <i class=\"fas fa-id-card fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                            <span>任务 ID：</span> <span>"+id+"</span><br>\n" +
                        "                            <i class=\"fas fa-tools fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                            <span>算  法：</span> <span>"+taskAbss[c].ALGORITHM+"</span><br>\n" +
                        "                            <i class=\"fas fa-clock fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                            <span>运行时间：</span> <span >"+time+"</span><br>\n" +
                        "                            <i class=\"fas fa-redo fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                            <span>仿真次数：</span> <span >"+taskAbss[c].CURRENTFE+"</span><br>\n" +
                        "                          </div>\n" +
                        "                        <div class=\"col-auto\">\n" +
                        "\n" +
                        "                          <i class=\"fas fa-battery-full fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                          <span>状  态：</span> <span >"+S+"</span> <br>\n" +
                        "                          <i class=\"fas fa-chart-line fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                          <span>M<sub>in</sub>M<sub>ax</sub>误差：</span> <span >"+Math.floor(taskAbss[c].MINMAXERROR * 100000) / 1000 + "%"+"</span><br>\n" +
                        "                          <i class=\"fas fa-chart-line fa-sm fa-fw mr-2 text-dark\"></i>\n" +
                        "                          <span>标准误差：</span> <span>"+taskAbss[c].AVGERROR+"</span><br>\n" +
                        "\n" +
                        "                        </div>\n" +
                        "                      </div>"
                break;
            }
        }

    }

    return data;
}
